<?php
/**
 * @file
 * A cached plugin object that tests inheritence including.
 */

class ctoolsCachedPluginArray {}
